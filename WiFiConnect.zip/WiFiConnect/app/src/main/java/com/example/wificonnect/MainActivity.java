package com.example.wificonnect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //String url = "https://www.archeva.in/wp-admin";
    String url;

    String username;
    String password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText userEdit = findViewById(R.id.username);
        username = userEdit.getText().toString();

        EditText passEdit = findViewById(R.id.username);
        password = passEdit.getText().toString();

        Button submitBtn = findViewById(R.id.Connect);

        submitBtn.setOnClickListener(view -> {

            Intent intent = new Intent(this, Login.class);
            intent.putExtra(username, password);
            startActivity(intent);

        });

    }

}