package com.example.wificonnect;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.Toolbar;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // perform whatever you want on back arrow click
            }
        });


        String url = "https://192.168.1.254:8090/";

        String username = "2021B1541201";
        String password = "Utkarsh5474";

        WebView myWebView = (WebView) findViewById(R.id.webview);


        final String js = "javascript:document.getElementById('username').value='"+username+"';"
                + "document.getElementById('password').value='"+password+"';"
                +"document.getElementById('loginbutton').click()";

        myWebView.loadUrl(url);
        myWebView.getSettings().setJavaScriptEnabled(true);


        myWebView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                view.evaluateJavascript(js, new ValueCallback<String>() {


                    @Override
                    public void onReceiveValue(String s) {
                        Log.d("ReceivedValue", "onReceiveValue: " +s);
                        Toast.makeText(getApplicationContext(), "Connected Successfully!", Toast.LENGTH_SHORT).show();
                    }

                });

            }});

        /*
        findViewById(R.id.lock).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //login(username, password);

            }
        });*/

    }


    public void login(String username, String password){


        /*
        final String js = "javascript:document.getElementById('username').value='"+username+"';"
                + "document.getElementById('password').value='"+password+"';"
                +"document.getElementById('loginbutton').click()"; */

    }

}